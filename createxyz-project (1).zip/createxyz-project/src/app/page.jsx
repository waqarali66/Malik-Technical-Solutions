"use client";
import React from "react";

function MainComponent() {
  const [currentTab, setCurrentTab] = React.useState("services");
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const services = [
    { title: "Event Planning", icon: "fa-glass-cheers" },
    { title: "General Vendor", icon: "fa-box" },
    { title: "Mess Services", icon: "fa-concierge-bell" },
    { title: "Decoration", icon: "fa-home" },
    { title: "Janitorial", icon: "fa-spray-can" },
    { title: "Security", icon: "fa-user-shield" },
    { title: "Construction", icon: "fa-building" },
    { title: "Carpentry", icon: "fa-screwdriver" },
    { title: "Electrical Work", icon: "fa-plug" },
    { title: "Plumbing", icon: "fa-wrench" },
    { title: "Painting", icon: "fa-brush" },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-[#ff6b00] text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold font-roboto">
            Malik Technical Solutions
          </h1>
          <div className="hidden md:flex space-x-6">
            <button
              onClick={() => setCurrentTab("services")}
              className="font-poppins"
            >
              Services
            </button>
            <button
              onClick={() => setCurrentTab("about")}
              className="font-poppins"
            >
              About
            </button>
            <button
              onClick={() => setCurrentTab("contact")}
              className="font-poppins"
            >
              Contact
            </button>
            <button className="bg-white text-[#1a237e] px-4 py-2 rounded-lg font-poppins">
              Login
            </button>
          </div>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden"
          >
            <i className="fas fa-bars text-2xl"></i>
          </button>
        </div>
        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4">
            <button
              onClick={() => setCurrentTab("services")}
              className="block w-full text-left font-poppins"
            >
              Services
            </button>
            <button
              onClick={() => setCurrentTab("about")}
              className="block w-full text-left font-poppins"
            >
              About
            </button>
            <button
              onClick={() => setCurrentTab("contact")}
              className="block w-full text-left font-poppins"
            >
              Contact
            </button>
            <button className="bg-white text-[#1a237e] px-4 py-2 rounded-lg w-full font-poppins">
              Login
            </button>
          </div>
        )}
      </nav>

      <main className="container mx-auto px-4 py-8">
        <section className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 font-roboto">
            Professional Services at Your Fingertips
          </h2>
          <p className="text-gray-600 font-poppins">
            Connect with skilled professionals for all your technical needs
          </p>
        </section>

        <section className="bg-white p-8 rounded-lg shadow-md mb-12">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <img
              src="https://ucarecdn.com/6b6972f6-89e2-40ba-980d-ab7d10386719/-/format/auto/"
              alt="Managing Director Waqar Ali"
              className="w-48 h-48 rounded-full object-cover border-4 border-[#ff6b00]"
            />
            <div>
              <h3 className="text-2xl font-bold mb-2 font-roboto">
                Meet Our Managing Director - Waqar Ali
              </h3>
              <p className="text-gray-600 mb-4 font-poppins">
                With 7 years of extensive experience in technical solutions and
                project management, I've successfully led numerous projects
                across Pakistan. My expertise spans electrical systems,
                construction management, and technical consultancy. At Malik
                Technical Solutions, we're committed to delivering professional
                and reliable solutions for all your technical needs.
              </p>
              <div className="flex gap-4">
                <div className="text-center">
                  <span className="text-[#ff6b00] text-2xl font-bold">7+</span>
                  <p className="text-sm">Years Experience</p>
                </div>
                <div className="text-center">
                  <span className="text-[#ff6b00] text-2xl font-bold">
                    500+
                  </span>
                  <p className="text-sm">Projects Completed</p>
                </div>
                <div className="text-center">
                  <span className="text-[#ff6b00] text-2xl font-bold">
                    100%
                  </span>
                  <p className="text-sm">Client Satisfaction</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            >
              <i
                className={`fas ${service.icon} text-3xl text-[#ff6b00] mb-4`}
              ></i>
              <h3 className="font-medium font-poppins">{service.title}</h3>
            </div>
          ))}
        </div>

        <section className="mt-16 text-center">
          <h3 className="text-2xl font-bold mb-4 font-roboto">
            Need a Service?
          </h3>
          <button className="bg-[#ff6b00] text-white px-8 py-3 rounded-lg hover:bg-[#ff8533] transition-colors font-poppins">
            Book Now
          </button>
        </section>

        <footer className="mt-16 border-t pt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-bold mb-4 font-roboto">Contact Us</h4>
              <p className="font-poppins">
                Email: Maliktechnicalsolutions@gmail.com
              </p>
              <p className="font-poppins">Phone: 03107667720</p>
              <p className="font-poppins">Contact Person: Waqar Ali</p>
            </div>
            <div className="text-right">
              <h4 className="font-bold mb-4 font-roboto">Follow Us</h4>
              <div className="space-x-4">
                <i className="fab fa-facebook text-2xl text-[#ff6b00] cursor-pointer"></i>
                <i className="fab fa-twitter text-2xl text-[#ff6b00] cursor-pointer"></i>
                <i className="fab fa-instagram text-2xl text-[#ff6b00] cursor-pointer"></i>
              </div>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}

export default MainComponent;